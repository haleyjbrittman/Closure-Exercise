import UIKit

let multiply = {
   (val1: Int, val2: Int) -> Int in
   return val1 * val2
}
let result = multiply(5, 2)
print; result
